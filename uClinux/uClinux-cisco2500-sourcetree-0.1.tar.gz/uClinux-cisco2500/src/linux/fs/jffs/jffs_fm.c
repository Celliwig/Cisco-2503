/*
 * JFFS -- Journalling Flash File System, Linux implementation.
 *
 * Copyright (C) 1999, 2000  Finn Hakansson, Axis Communications, Inc.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * $Id: jffs_fm.c,v 1.40 2000/01/05 14:29:09 finn Exp $
 *
 */

#include <linux/malloc.h>
#include <linux/blkdev.h>
#include <linux/jffs.h>
#include "jffs_fm.h"

#if defined(CONFIG_JFFS_FS_VERBOSE) && CONFIG_JFFS_FS_VERBOSE
#define D(x) x
#else
#define D(x)
#endif
#define D1(x)
#define D2(x)
#define D3(x)
#define ASSERT(x) x

#if defined(JFFS_MARK_OBSOLETE) && JFFS_MARK_OBSOLETE
static int jffs_mark_obsolete(struct jffs_fmcontrol *fmc, __u32 fm_offset);
#endif


/* This function creates a new shiny flash memory control structure.  */
struct jffs_fmcontrol *
jffs_build_begin(struct jffs_control *c, kdev_t dev)
{
	struct jffs_fmcontrol *fmc;

	D3(printk("jffs_build_begin()\n"));
	fmc = (struct jffs_fmcontrol *)kmalloc(sizeof(struct jffs_fmcontrol),
					       GFP_KERNEL);
	if (!fmc) {
		D(printk("jffs_build_begin(): Allocation of "
			 "struct jffs_fmcontrol failed!\n"));
		return (struct jffs_fmcontrol *)0;
	}
	DJM(no_jffs_fmcontrol++);

	/* Retrieve the size of the flash memory.  */
#ifdef CONFIG_SVINTO_SIM
	fmc->flash_start = 0;
	fmc->flash_size = 262144;
#else
#if defined(JFFS_FLASH_SHORTCUT) && JFFS_FLASH_SHORTCUT
	fmc->flash_start = (__u32) flash_get_direct_pointer (dev, 0);
#else
	fmc->flash_start = 0;
#endif
	fmc->flash_size = blk_size[MAJOR(dev)][MINOR(dev)] << BLOCK_SIZE_BITS;
#endif
	D3(printk("  fmc->flash_start = 0x%08x\n", fmc->flash_start));
	D3(printk("  fmc->flash_size = %d bytes\n", fmc->flash_size));

	fmc->used_size = 0;
	fmc->dirty_size = 0;
	fmc->sector_size = 65536;
	fmc->max_chunk_size = fmc->sector_size >> 1;
	fmc->min_free_size = (fmc->sector_size << 1) - fmc->max_chunk_size;
#if defined(JFFS_FLASH_SHORTCUT) && JFFS_FLASH_SHORTCUT
	fmc->flash_part = flash_getpart(dev);
#else
	fmc->flash_part = 0;
#endif
	fmc->no_call_gc = 0;
	fmc->c = c;
	fmc->head = 0;
	fmc->tail = 0;
	fmc->head_extra = 0;
	fmc->tail_extra = 0;
	return fmc;
}


/* When the flash memory scan has completed, this function should be called
   before use of the control structure.  */
void
jffs_build_end(struct jffs_fmcontrol *fmc)
{
	D3(printk("jffs_build_end()\n"));

	if (!fmc->head) {
		fmc->head = fmc->head_extra;
		fmc->tail = fmc->tail_extra;
	}
	else if (fmc->head_extra) {
		fmc->tail_extra->next = fmc->head;
		fmc->head->prev = fmc->tail_extra;
		fmc->head = fmc->head_extra;
	}
	fmc->head_extra = 0; /* These two instructions should be omitted.  */
	fmc->tail_extra = 0;
	D3(jffs_print_fmcontrol(fmc));
}


/* Call this function when the file system is unmounted.  This function
   frees all memory used by this module.  */
void
jffs_cleanup_fmcontrol(struct jffs_fmcontrol *fmc)
{
	if (fmc) {
		struct jffs_fm *cur;
		struct jffs_fm *next = fmc->head;

		while ((cur = next)) {
			next = next->next;
			kfree(cur);
			DJM(no_jffs_fm--);
		}
		kfree(fmc);
		DJM(no_jffs_fmcontrol--);
	}
}


/* This function returns the size of the first chunk of free space on the
   flash memory.  This function will return something nonzero if the flash
   memory contains any free space.  */
__u32
jffs_free_size1(struct jffs_fmcontrol *fmc)
{
	__u32 head;
	__u32 tail;
	__u32 end = fmc->flash_start + fmc->flash_size;

	if (!fmc->head) {
		/* There is nothing on the flash.  */
		return fmc->flash_size;
	}

	/* Compute the beginning and ending of the contents of the flash.  */
	head = fmc->head->offset;
	tail = fmc->tail->offset + fmc->tail->size;
	if (tail == end) {
		tail = fmc->flash_start;
	}
	ASSERT(else if (tail > end) {
		printk(KERN_WARNING "jffs_free_size1(): tail > end\n");
		tail = fmc->flash_start;
	});

	if (head <= tail) {
		return end - tail;
	}
	else {
		return head - tail;
	}
}

/* This function will return something nonzero in case there are two free
   areas on the flash.  Like this:

     +----------------+------------------+----------------+
     |     FREE 1     |   USED / DIRTY   |     FREE 2     |
     +----------------+------------------+----------------+
       fmc->head -----^
       fmc->tail ------------------------^

   The value returned, will be the size of the first empty area on the
   flash, in this case marked "FREE 1".  */
__u32
jffs_free_size2(struct jffs_fmcontrol *fmc)
{
	if (fmc->head) {
		__u32 head = fmc->head->offset;
		__u32 tail = fmc->tail->offset + fmc->tail->size;
		if (tail == fmc->flash_start + fmc->flash_size) {
			tail = fmc->flash_start;
		}

		if (tail >= head) {
			return head - fmc->flash_start;
		}
	}
	return 0;
}


/* Allocate a chunk of flash memory.  If there is enough space on the
   device, a reference to the associated node is stored in the jffs_fm
   struct.  */
int
jffs_fmalloc(struct jffs_fmcontrol *fmc, __u32 size, struct jffs_node *node,
	     struct jffs_fm **result)
{
	struct jffs_fm *fm;
	__u32 free_chunk_size1;
	__u32 free_chunk_size2;

	D2(printk("jffs_fmalloc(): fmc = 0x%p, size = %d, "
		  "node = 0x%p\n", fmc, size, node));

	*result = 0;

	if (!(fm = (struct jffs_fm*)kmalloc(sizeof(struct jffs_fm),
					    GFP_KERNEL))) {
		D(printk("jffs_fmalloc(): kmalloc() failed! (fm)\n"));
		return -ENOMEM;
	}
	DJM(no_jffs_fm++);

	free_chunk_size1 = jffs_free_size1(fmc);
	free_chunk_size2 = jffs_free_size2(fmc);
	D3(printk("jffs_fmalloc(): free_chunk_size1 = %u, "
		  "free_chunk_size2 = %u\n",
		  free_chunk_size1, free_chunk_size2));

	if (size <= free_chunk_size1) {
		if (!(fm->nodes = (struct jffs_node_ref *)
				  kmalloc(sizeof(struct jffs_node_ref),
					  GFP_KERNEL))) {
			D(printk("jffs_fmalloc(): kmalloc() failed! "
				 "(node_ref)\n"));
			kfree(fm);
			DJM(no_jffs_fm--);
			return -ENOMEM;
		}
		DJM(no_jffs_node_ref++);
		fm->nodes->node = node;
		fm->nodes->next = 0;
		if (fmc->tail) {
			fm->offset = fmc->tail->offset + fmc->tail->size;
			if (fm->offset
			    == fmc->flash_start + fmc->flash_size) {
				fm->offset = fmc->flash_start;
			}
			ASSERT(else if (fm->offset
					> fmc->flash_start
					  + fmc->flash_size) {
				printk(KERN_WARNING "jffs_fmalloc(): "
				       "offset > flash_end\n");
				fm->offset = fmc->flash_start;
			});
		}
		else {
			/* There don't have to be files in the file
			   system yet.  */
			fm->offset = fmc->flash_start;
		}
		fm->size = size;
		fmc->used_size += size;
	}
	else if (size > free_chunk_size2) {
		printk(KERN_WARNING "JFFS: Tried to allocate a too "
		       "large flash memory chunk. (size = %u)\n", size);
		kfree(fm);
		DJM(no_jffs_fm--);
		return -ENOSPC;
	}
	else {
		fm->offset = fmc->tail->offset + fmc->tail->size;
		fm->size = free_chunk_size1;
		fm->nodes = 0;
		fmc->dirty_size += size;
	}

	fm->next = 0;
	if (!fmc->head) {
		fm->prev = 0;
		fmc->head = fm;
		fmc->tail = fm;
	}
	else {
		fm->prev = fmc->tail;
		fmc->tail->next = fm;
		fmc->tail = fm;
	}

	D3(jffs_print_fmcontrol(fmc));
	D3(jffs_print_fm(fm));
	*result = fm;
	return 0;
}


/* The on-flash space is not needed anymore by the passed node.  Remove
   the reference to the node from the node list.  If the data chunk in
   the flash memory isn't used by any more nodes anymore (fm->nodes == 0),
   then mark that chunk as dirty.  */
int
jffs_fmfree(struct jffs_fmcontrol *fmc, struct jffs_fm *fm, struct jffs_node *node)
{
	struct jffs_node_ref *ref;
	struct jffs_node_ref *prev;
	ASSERT(int del = 0);

	D2(printk("jffs_fmfree(): node->ino = %u, node->version = %u\n",
		 node->ino, node->version));

	ASSERT(if (!fmc || !fm || !fm->nodes) {
		printk(KERN_ERR "jffs_fmfree(): fmc: 0x%p, fm: 0x%p, "
		       "fm->nodes: 0x%p\n",
		       fmc, fm, (fm ? fm->nodes : 0));
		return -1;
	});

	/* Find the reference to the node that is going to be removed
	   and remove it.  */
	for (ref = fm->nodes, prev = 0; ref; ref = ref->next) {
		if (ref->node == node) {
			if (prev) {
				prev->next = ref->next;
			}
			else {
				fm->nodes = ref->next;
			}
			kfree(ref);
			DJM(no_jffs_node_ref--);
			ASSERT(del = 1);
			break;
		}
		prev = ref;
	}

	/* If the data chunk in the flash memory isn't used anymore
	   just mark it as obsolete.  */
	if (!fm->nodes) {
		/* No node uses this chunk so let's remove it.  */
		fmc->used_size -= fm->size;
		fmc->dirty_size += fm->size;
#if defined(JFFS_MARK_OBSOLETE) && JFFS_MARK_OBSOLETE
		if (jffs_mark_obsolete(fmc, fm->offset) < 0) {
			D1(printk("jffs_fmfree(): Failed to mark an on-flash "
				  "node obsolete!\n"));
			return -1;
		}
#endif
		fmc->c->sb->s_dirt = 1;
	}

	ASSERT(if (!del) {
		printk(KERN_WARNING "***jffs_fmfree(): "
		       "Didn't delete any node reference!\n");
	});

	return 0;
}


/* This allocation function is used during the initialization of
   the file system.  */
struct jffs_fm *
jffs_fmalloced(struct jffs_fmcontrol *fmc, __u32 offset, __u32 size,
	       struct jffs_node *node)
{
	struct jffs_fm *fm;

	D3(printk("jffs_fmalloced()\n"));

	if (!(fm = (struct jffs_fm *)kmalloc(sizeof(struct jffs_fm),
					     GFP_KERNEL))) {
		D(printk("jffs_fmalloced(0x%p, %u, %u, 0x%p): failed!\n",
			 fmc, offset, size, node));
		return 0;
	}
	DJM(no_jffs_fm++);
	fm->offset = offset;
	fm->size = size;
	fm->prev = 0;
	fm->next = 0;
	fm->nodes = 0;
	if (node) {
		/* `node' exists and it should be associated with the
		    jffs_fm structure `fm'.  */
		if (!(fm->nodes = (struct jffs_node_ref *)
				  kmalloc(sizeof(struct jffs_node_ref),
					  GFP_KERNEL))) {
			D(printk("jffs_fmalloced(): !fm->nodes\n"));
			kfree(fm);
			DJM(no_jffs_fm--);
			return 0;
		}
		DJM(no_jffs_node_ref++);
		fm->nodes->node = node;
		fm->nodes->next = 0;
		fmc->used_size += size;
	}
	else {
		/* If there is no node, then this is just a chunk of dirt.  */
		fmc->dirty_size += size;
	}

	if (fmc->head_extra) {
		fm->prev = fmc->tail_extra;
		fmc->tail_extra->next = fm;
		fmc->tail_extra = fm;
	}
	else if (!fmc->head) {
		fmc->head = fm;
		fmc->tail = fm;
	}
	else if (fmc->tail->offset + fmc->tail->size < offset) {
		fmc->head_extra = fm;
		fmc->tail_extra = fm;
	}
	else {
		fm->prev = fmc->tail;
		fmc->tail->next = fm;
		fmc->tail = fm;
	}
	D3(jffs_print_fmcontrol(fmc));
	D3(jffs_print_fm(fm));
	return fm;
}


/* Add a new node to an already existing jffs_fm struct.  */
int
jffs_add_node(struct jffs_node *node)
{
	struct jffs_node_ref *ref;
	struct jffs_fm *fm = node->fm;
	int s = sizeof(struct jffs_node_ref);

	D3(printk("jffs_add_node(): ino = %u\n", node->ino));

	if (!(ref = (struct jffs_node_ref *)kmalloc(s, GFP_KERNEL))) {
		return -ENOMEM;
	}
	DJM(no_jffs_node_ref++);
	ref->node = node;
	ref->next = fm->nodes;
	fm->nodes = ref;
	return 0;
}


/* Free a part of some allocated space.  */
void
jffs_fmfree_partly(struct jffs_fmcontrol *fmc, struct jffs_fm *fm, __u32 size)
{
	D1(printk("***jffs_fmfree_partly(): fm = 0x%p, fm->nodes = 0x%p, "
		  "fm->nodes->node->ino = %u, size = %u\n",
		  fm, (fm ? fm->nodes : 0),
		  (!fm ? 0 : (!fm->nodes ? 0 : fm->nodes->node->ino)), size));

	if (fm->nodes) {
		kfree(fm->nodes);
		DJM(no_jffs_node_ref--);
		fm->nodes = 0;
	}
	fmc->used_size -= fm->size;
	if (fm == fmc->tail) {
		fm->size -= size;
	}
	fmc->dirty_size += fm->size;
}


/* Find the jffs_fm struct that contains the end of the data chunk that
   begins at the logical beginning of the flash memory and spans `size'
   bytes.  If we want to erase a sector of the flash memory, we use this
   function to find where the sector limit cuts a chunk of data.  */
struct jffs_fm *
jffs_cut_node(struct jffs_fmcontrol *fmc, __u32 size)
{
	struct jffs_fm *fm;
	__u32 pos = 0;

	if (size == 0) {
		return 0;
	}

	ASSERT(if (!fmc) {
		printk(KERN_ERR "jffs_cut_node(): fmc == NULL\n");
		return 0;
	});

	fm = fmc->head;

	while (fm) {
		pos += fm->size;
		if (pos < size) {
			fm = fm->next;
		}
		else if (pos > size) {
			break;
		}
		else {
			fm = 0;
			break;
		}
	}

	return fm;
}


/* Move the head of the fmc structures and delete the obsolete parts.  */
void
jffs_sync_erase(struct jffs_fmcontrol *fmc, int erased_size)
{
	struct jffs_fm *fm;
	struct jffs_fm *del;

	ASSERT(if (!fmc) {
		printk(KERN_ERR "jffs_sync_erase(): fmc == NULL\n");
		return;
	});

	fmc->dirty_size -= erased_size;

	for (fm = fmc->head; fm && (erased_size > 0);) {
		if (erased_size >= fm->size) {
			erased_size -= fm->size;
			del = fm;
			fm = fm->next;
			fm->prev = 0;
			fmc->head = fm;
			kfree(del);
			DJM(no_jffs_fm--);
		}
		else {
			fm->size -= erased_size;
			fm->offset += erased_size;
			break;
		}
	}
}


/* Return the oldest used node in the flash memory.  */
struct jffs_node *
jffs_get_oldest_node(struct jffs_fmcontrol *fmc)
{
	struct jffs_fm *fm;
	struct jffs_node_ref *nref;
	struct jffs_node *node = 0;

	ASSERT(if (!fmc) {
		printk(KERN_ERR "jffs_get_oldest_node(): fmc == NULL\n");
		return 0;
	});

	for (fm = fmc->head; fm && !fm->nodes; fm = fm->next);

	if (!fm) {
		return 0;
	}

	/* The oldest node is the last one in the reference list.  This list
	   shouldn't be too long; just one or perhaps two elements.  */
	for (nref = fm->nodes; nref; nref = nref->next) {
		node = nref->node;
	}

	D2(printk("jffs_get_oldest_node(): ino = %u, version = %u\n",
		  (node ? node->ino : 0), (node ? node->version : 0)));

	return node;
}


#if defined(JFFS_MARK_OBSOLETE) && JFFS_MARK_OBSOLETE
#if defined(JFFS_FLASH_SHORTCUT) && JFFS_FLASH_SHORTCUT

/* Mark an on-flash node as obsolete.

   Note that this is just an optimization that isn't necessary for the
   filesystem to work.  */

static int
jffs_mark_obsolete(struct jffs_fmcontrol *fmc, __u32 fm_offset)
{
	/* The `accurate_pos' holds the position of the accurate byte
	   in the jffs_raw_inode structure that we are going to mark
	   as obsolete.  */
	__u32 accurate_pos = fm_offset + JFFS_RAW_INODE_ACCURATE_OFFSET;
	unsigned char zero = 0x00;

	D3(printk("jffs_mark_obsolete(): accurate_pos = %u\n", accurate_pos));
	ASSERT(if (!fmc) {
		printk(KERN_ERR "jffs_mark_obsolete(): fmc == NULL\n");
		return -1;
	});

	/* Write 0x00 to the raw inode's accurate member.  Don't care
	   about the return value.  */
	flash_safe_write(fmc->flash_part, (unsigned char *) accurate_pos,
			 &zero, 1);
	return 0;
}

#else

/* Mark an on-flash node as obsolete.  */
static int
jffs_mark_obsolete(struct jffs_fmcontrol *fmc, __u32 fm_offset)
{
	struct buffer_head *bh;
	/* The `accurate_pos' holds the position of the accurate byte
	   in the jffs_raw_inode structure that we are going to mark
	   as obsolete.  */
	__u32 accurate_pos = fm_offset + JFFS_RAW_INODE_ACCURATE_OFFSET;
	__u32 block = accurate_pos / BLOCK_SIZE;

	D3(printk("jffs_mark_obsolete(): accurate_pos = %u, block = %d\n",
		  accurate_pos, block));
	ASSERT(if (!fmc) {
		printk(KERN_ERR "jffs_mark_obsolete(): fmc == NULL\n");
		return -1;
	});
	ASSERT(if (accurate_pos == 0) {
		printk(KERN_ERR "jffs_mark_obsolete(): accurate_pos = 0\n");
	});

	if (!(bh = bread(fmc->c->sb->s_dev, block, BLOCK_SIZE))) {
		D(printk("jffs_mark_obsolete(): bread() failed. "
			 "(block == %u)\n", block));
		return -1;
	}

	/* Write 0x00 to the raw inode.  */
	bh->b_data[accurate_pos - block * BLOCK_SIZE] = (char)0x00;

	jffs_put_write_buffer(bh);
	return 0;
}

#endif /* JFFS_FLASH_SHORTCUT  */
#endif /* JFFS_MARK_OBSOLETE  */


/* How much dirty flash memory is possible to erase at the moment?  */
long
jffs_erasable_size(struct jffs_fmcontrol *fmc)
{
	struct jffs_fm *fm;
	__u32 size = 0;
	long ret;

	ASSERT(if (!fmc) {
		printk(KERN_ERR "jffs_erasable_size(): fmc = NULL\n");
		return -1;
	});

	if (!fmc->head) {
		/* The flash memory is totally empty. No nodes. No dirt.
		   Just return.  */
		return 0;
	}

	/* Calculate how much space that is dirty.  */
	for (fm = fmc->head; fm && !fm->nodes; fm = fm->next) {
		if (size && fm->offset == fmc->flash_start) {
			/* We have reached the beginning of the flash.  */
			break;
		}
		size += fm->size;
	}

	/* Someone's signature contained this:
	   There's a fine line between fishing and just standing on
	   the shore like an idiot...  */
	ret = flash_erasable_size(fmc->flash_part,
				  fmc->head->offset - fmc->flash_start, size);

	ASSERT(if (ret < 0) {
		printk("jffs_erasable_size: flash_erasable_size() "
		       "returned something less than zero (%ld).\n", ret);
		printk("jffs_erasable_size: offset = 0x%08x\n",
		       fmc->head->offset - fmc->flash_start);
	});

	/* If there is dirt on the flash (which is the reason to why
	   this function was called in the first place) but no space is
	   possible to erase right now, the initial part of the list of
	   jffs_fm structs, that hold place for dirty space, could perhaps
	   be shortened.  The list's initial "dirty" elements are merged
	   into just one large dirty jffs_fm struct.  This operation must
	   only be performed if nothing is possible to erase.  Otherwise,
	   jffs_clear_end_of_node() won't work as expected.  */
	if (ret == 0) {
		struct jffs_fm *head = fmc->head;
		struct jffs_fm *del;
		while (head->nodes == 0
		       && head->next
		       && head->next->nodes == 0) {
			del = head->next;
			head->size += del->size;
			head->next = del->next;
			if (del->next) {
				del->next->prev = head;
			}
			kfree(del);
			DJM(no_jffs_fm--);
		}
	}

	return (ret >= 0 ? ret : 0);
}


void
jffs_print_fmcontrol(struct jffs_fmcontrol *fmc)
{
	D(printk("struct jffs_fmcontrol: 0x%p\n", fmc));
	D(printk("{\n"));
	D(printk("        0x%08x, /* flash_start  */\n", fmc->flash_start));
	D(printk("        %u, /* flash_size  */\n", fmc->flash_size));
	D(printk("        %u, /* used_size  */\n", fmc->used_size));
	D(printk("        %u, /* dirty_size  */\n", fmc->dirty_size));
	D(printk("        %u, /* sector_size  */\n", fmc->sector_size));
	D(printk("        %u, /* min_free_size  */\n", fmc->min_free_size));
	D(printk("        %u, /* max_chunk_size  */\n", fmc->max_chunk_size));
	D(printk("        0x%p, /* flash_part  */\n", fmc->flash_part));
	D(printk("        0x%p, /* head  */    "
		 "(head->offset = 0x%08x)\n",
		 fmc->head, (fmc->head ? fmc->head->offset : 0)));
	D(printk("        0x%p, /* tail  */    "
		 "(tail->offset + tail->size = 0x%08x)\n",
		 fmc->tail,
		 (fmc->tail ? fmc->tail->offset + fmc->tail->size : 0)));
	D(printk("        0x%p, /* head_extra  */\n", fmc->head_extra));
	D(printk("        0x%p, /* tail_extra  */\n", fmc->tail_extra));
	D(printk("}\n"));
}

void
jffs_print_fm(struct jffs_fm *fm)
{
	D(printk("struct jffs_fm: 0x%p\n", fm));
	D(printk("{\n"));
	D(printk("       0x%08x, /* offset  */\n", fm->offset));
	D(printk("       %u, /* size  */\n", fm->size));
	D(printk("       0x%p, /* prev  */\n", fm->prev));
	D(printk("       0x%p, /* next  */\n", fm->next));
	D(printk("       0x%p, /* nodes  */\n", fm->nodes));
	D(printk("}\n"));
}

void
jffs_print_node_ref(struct jffs_node_ref *ref)
{
	D(printk("struct jffs_node_ref: 0x%p\n", ref));
	D(printk("{\n"));
	D(printk("       0x%p, /* node  */\n", ref->node));
	D(printk("       0x%p, /* next  */\n", ref->next));
	D(printk("}\n"));
}
